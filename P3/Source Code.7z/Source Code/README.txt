The steps for testing the project are as follows:

1. Create a project in your Java IDE (e.g. Eclipse).
2. Copy all class files from folder "source code" to your project src folder.
3. Copy all CSV files from inside folder "data" to your project root directory.
4. On your Java IDE, run "DiagnoseMe.java".
5. In the console, input your query in one line, separating each symptom with a comma ",".
6. Press enter and you should see the result in the console.